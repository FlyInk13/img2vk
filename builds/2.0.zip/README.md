# [Отправить фото ВКонтакте](https://chrome.google.com/webstore/kbafjbahbohbfeifjpgomdlkcjcmdgfi)

Google Chrome расширение для отправки фото из контекстного меню
